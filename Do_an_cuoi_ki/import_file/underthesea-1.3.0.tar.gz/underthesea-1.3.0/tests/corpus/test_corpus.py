from unittest import TestCase

from underthesea.corpus import Corpus


class TestCorpus(TestCase):
    def test___init__(self):
        Corpus()
