Underthesea documentation
=========================

Vietnamese NLP Toolkit

.. toctree::
   :maxdepth: 1
   :caption: Notes

   readme
   authors
   history

.. toctree::
   :maxdepth: 1
   :caption: Package Reference

   package_reference

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
