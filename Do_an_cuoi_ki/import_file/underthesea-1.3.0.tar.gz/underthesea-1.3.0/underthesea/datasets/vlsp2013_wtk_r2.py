class VLSP2013_WTK_R2:
    def __init__(self):
        self.name = "VLSP2013-WTK-R2"
