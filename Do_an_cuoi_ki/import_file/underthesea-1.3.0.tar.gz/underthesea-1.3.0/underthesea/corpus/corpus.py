class Corpus:
    """Interface for corpus
    """
    def __init__(self):
        pass
